<div class="course-details-area">
    <br>
    <div class="container">
        <div class="row">
            <!-- Start Course Info -->
            <div class="col-md-12">
                <div class="courses-info">
                    <h2>
                        Branch Details
                    </h2>

                    <!-- Star Tab Info -->
                    <div class="tab-info">
                        <!-- Tab Nav -->
                        <ul class="nav nav-pills">
                            <li class="active">
                                <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                    PRODUCTION ENGINEERING </a>
                            </li>

                            <li>
                                <a data-toggle="tab" href="#tab3" aria-expanded="false">
                                    Faculty
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#tab4" aria-expanded="false">
                                    Labs
                                </a>
                            </li>
                        </ul>
                        <!-- End Tab Nav -->
                        <!-- Start Tab Content -->
                        <div class="tab-content tab-content-info">
                            <!-- Single Tab -->
                            <div id="tab1" class="tab-pane fade active in">
                                <div class="info title">
                                    <h4>Vision</h4>
                                    <p> To emerge as a leading production engineering department in the state of Gujarat, continuously responding to industrial, social and economic environment, striving for excellence and growth.</p>

                                    <h4>Mission</h4>
                                    <p> To offer need based technical programs and services in the area of production engineering to meet the ever-changing expectations of the industries to their ultimate satisfaction.
                                    </p>
                                </div>
                            </div>
                            <!-- End Single Tab -->



                            <!-- Single Tab -->
                            <div id="tab3" class="tab-pane fade">
                                <div class="info title">
                                    <div class="advisor-list-items row container">
                                        <!-- Advisor Item -->

                                        <div class="item col-md-6">
                                            <div class="thumb">
                                                <img src="" alt="Thumb">
                                            </div>
                                            <div class="info">
                                                <div class="author">
                                                    <h4></h4>
                                                    <ul>
                                                        <li class="dribbble">
                                                            <a href="#"><i class="far fa-envelope"></i></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="b-portfolio_info">
                                                    <hr>
                                                    <div class="b-portfolio_info_description f-portfolio_info_description">
                                                        <div class="b-information-box f-information-box f-primary-b">
                                                            <ul>
                                                                <li>
                                                                    <strong class="f-information-box__name b-information-box__name">Designation</strong>
                                                                    <i class="b-dotted f-dotted">:</i>
                                                                    <span class="f-information_data"></span>
                                                                </li>
                                                                <br>
                                                                <li>
                                                                    <strong class="f-information-box__name b-information-box__name">Qualification</strong>
                                                                    <i class="b-dotted f-dotted">:</i>
                                                                    <span class="f-information_data"></span>
                                                                </li><br>
                                                                <li>
                                                                    <strong class="f-information-box__name b-information-box__name">Experience</strong>
                                                                    <i class="b-dotted f-dotted">:</i>
                                                                    <span class="f-information_data"></span>
                                                                </li><br>
                                                                <li>
                                                                    <strong class="f-information-box__name b-information-box__name">Area
                                                                        Of Interest </strong>
                                                                    <i class="b-dotted f-dotted">:</i>
                                                                    <span class="f-information_data"></span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Advisor Item -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Tab -->

                            <!-- Single Tab -->
                            <div id="tab4" class="tab-pane fade">
                                <!-- Start Lab Details ============================================= -->
                                <div class="advisor-details-area ">
                                    <div class="container">
                                        <div class="row">
                                            <div class="advisor-info container">
                                                <!-- Start Thumbnail -->
                                                <div class="col-md-5">
                                                    <div class="thumb1">
                                                        <img src="http://www.gecbh.cteguj.in//uploads/6265/database1.jpg" alt="Thumb">
                                                    </div>
                                                </div>
                                                <!-- End Thumbnail -->

                                                <!-- Start Content -->
                                                <div class="col-md-7 content">
                                                    <div class="course-info-list">
                                                        <ul>
                                                            <li>
                                                                <h2>DATABASE LAB</h2>
                                                                <h5>This lab can be used to perform practicals related
                                                                    to Database</h5>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                                <!-- End Content -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <!-- End Lab Details ===========================================-->
                                <!-- Start Lab Details ============================================= -->
                                <div class="advisor-details-area ">
                                    <div class="container">
                                        <div class="row">
                                            <div class="advisor-info container">
                                                <!-- Start Thumbnail -->
                                                <div class="col-md-5">
                                                    <div class="thumb1">
                                                        <img src="http://www.gecbh.cteguj.in//uploads/6265/network1.jpg" alt="Thumb">
                                                    </div>
                                                </div>
                                                <!-- End Thumbnail -->

                                                <!-- Start Content -->
                                                <div class="col-md-7 content">
                                                    <div class="course-info-list">
                                                        <ul>
                                                            <li>
                                                                <h2>NETWORKING LAB</h2>
                                                                <h5>Students can carry out Networking related
                                                                    experiments in Networking Lab.</h5>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                                <!-- End Content -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <!-- End Lab Details ===========================================-->
                                <!-- Start Lab Details ============================================= -->
                                <div class="advisor-details-area ">
                                    <div class="container">
                                        <div class="row">
                                            <div class="advisor-info container">
                                                <!-- Start Thumbnail -->
                                                <div class="col-md-5">
                                                    <div class="thumb1">
                                                        <img src="http://www.gecbh.cteguj.in//uploads/6265/comp_dept.jpg" alt="Thumb">
                                                    </div>
                                                </div>
                                                <!-- End Thumbnail -->

                                                <!-- Start Content -->
                                                <div class="col-md-7 content">
                                                    <div class="course-info-list">
                                                        <ul>
                                                            <li>
                                                                <h2>ADVANCED PROGRAMMING LAB</h2>
                                                                <h5>Programming Practicals can be performed in this lab.
                                                                </h5>
                                                            </li>

                                                        </ul>
                                                    </div>
                                                </div>
                                                <!-- End Content -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <!-- End Lab Details ===========================================-->
                            </div>
                            <!-- End Single Tab -->
                        </div>
                        <!-- End Tab Content -->
                    </div>
                    <!-- End Tab Info -->
                </div>
            </div>
            <!-- End Course Info -->


        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_authontication\resources\views/livewire/cource/pecomponent.blade.php ENDPATH**/ ?>
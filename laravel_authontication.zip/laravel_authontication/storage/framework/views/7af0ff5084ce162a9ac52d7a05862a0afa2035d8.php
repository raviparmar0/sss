<div class="course-details-area">
    <br>
    <div class="container">
        <div class="row">
            <!-- Start Course Info -->
            <div class="col-md-12">
                <div class="courses-info">
                    <h2>
                        Facultys
                    </h2>
                    <div class="faq-inner">

                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">CIVIL ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($civi): ?>
                                            <?php $__currentLoopData = $civi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $civi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $civi->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($civi->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">COMPUTER ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($comp): ?>
                                            <?php $__currentLoopData = $comp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $comp->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($comp->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">ELECTRONICS & COMMUNICATION ENGG.<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($elec): ?>
                                            <?php $__currentLoopData = $elec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $elec->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($elec->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->

                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">INFORMATION TECHNOLOGY<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($info): ?>
                                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $info->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($info->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">MECHANICAL ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($mech): ?>
                                            <?php $__currentLoopData = $mech; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $mech->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($mech->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">PRODUCTION ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            <?php if($prod): ?>
                                            <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo e(asset('upload/faculties/' . $prod->photo)); ?>" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp<?php echo e($prod->f_name); ?></h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- End Course Info -->


        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sss-main\laravel_authontication\resources\views/livewire/facultycomponent.blade.php ENDPATH**/ ?>
 <?php if (isset($component)) { $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FacultyLayout::class, []); ?>
<?php $component->withName('faculty-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    Faculty
 <?php if (isset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655)): ?>
<?php $component = $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655; ?>
<?php unset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\sss-main\laravel_authontication\resources\views/faculty/dashboard.blade.php ENDPATH**/ ?>
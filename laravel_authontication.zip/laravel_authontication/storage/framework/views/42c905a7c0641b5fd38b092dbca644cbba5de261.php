 <?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="login-area">
        <div class="advisor-details-area">
            <div class="row advisor-info">
                <div class="col-md-6 col-md-offset-3 content">
                    <div class="tab-info">
                        <ul class="nav-pills">

                            <li class="col-md-4 active">
                                <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                    Student&nbspLogin
                                </a>
                            </li>
                            <li class="col-md-4">
                                <a data-toggle="tab" href="#tab1" aria-expanded="false">
                                    Faculty&nbspLogin
                                </a>
                            </li>
                            <li class="col-md-3">
                                <a data-toggle="tab" href="#tab1" aria-expanded="false">
                                    Admin&nbspLogin
                                </a>
                            </li>
                        </ul>
                        <br>
                        <br>
                        <div class="tab-content tab-content-info">
                            <!-- Single Tab -->
                            <div id="tab1" class="tab-pane fade active in">

                                <form action="<?php echo e(route('login')); ?>" method="post" id="login-form">

                                    <?php echo csrf_field(); ?>
                                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Email ID*" type="email"
                                                    name="email" required autofocus>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Password*" type="password"
                                                    name="password" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="row">
                                            <button type="submit">
                                                Login
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- End Single Tab -->
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Login Area -->
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\sss-main\laravel_authontication\resources\views/auth/login.blade.php ENDPATH**/ ?>
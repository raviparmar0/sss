 <?php if (isset($component)) { $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FacultyLayout::class, []); ?>
<?php $component->withName('faculty-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Selected Student</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Placement</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Selected Student</a></li>
                </ol>
            </div>
        </div>
        <?php if(Session::has('student_added')): ?>
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('student_added')); ?>

        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-xl-12 col-xxl-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('selected_student_submit')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Student Name</label>
                                        <input type="text" name="s_name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Enrollment Number</label>
                                        <input type="text" name="e_number" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Company Name</label>
                                        <input type="text" name="c_name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Branch</label>
                                        <select class="form-control" name="b_name" required>
                                            <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->b_name); ?>"><?php echo e($data->b_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Year</label>
                                        <input type="text" name="year" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <button type="submit" class="btn btn-light">Cencel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>



        </div>
    </div>

 <?php if (isset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655)): ?>
<?php $component = $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655; ?>
<?php unset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\sss-main\laravel_authontication\resources\views//faculty/company/selected_student.blade.php ENDPATH**/ ?>
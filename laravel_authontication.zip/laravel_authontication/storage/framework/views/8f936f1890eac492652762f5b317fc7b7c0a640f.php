 <?php if (isset($component)) { $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FacultyLayout::class, []); ?>
<?php $component->withName('faculty-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Event</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Event</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">All Event</a></li>
                </ol>
            </div>
        </div>
        <?php if(Session::has('event_added')): ?>
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(Session::get('event_added')); ?>

        </div>
        <?php endif; ?>
        <div class="row">


            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">View Event</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-1">
                            <table class="table m-1 table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr class="row">
                                        <th scope="col" class="col-md-2">Event Name</th>
                                        <th scope="col" class="col-md-2">Start Date</th>
                                        <th scope="col" class="col-md-2">End Date</th>
                                        <th scope="col" class="col-md-4">Discription</th>
                                        <th scope="col" class="col-md-2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="row">
                                        <td scope="col" class="col-md-2"><?php echo e($data->e_name); ?></td>
                                        <td scope="col" class="col-md-2"><?php echo e($data->s_date); ?> </td>
                                        <td scope="col" class="col-md-2"><?php echo e($data->e_date); ?></td>
                                        <td scope="col" class="col-md-4"><?php echo e($data->dis); ?></td>
                                        <td scope="col" class="col-md-2">
                                            <span>
                                                <a href="/faculty/edit_event/<?php echo e($data->id); ?>" class="mr-4" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil color-muted"></i> </a>
                                                <a data-action="<?php echo e(route('delete_event',$data->id)); ?>" class="remove-user mr-4 btn-sm " data-id="<?php echo e($data->id); ?>" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-close color-danger"></i></a>
                                                <a href="/download_event_faculty/<?php echo e($data->file); ?>" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-download color-danger"></i></a>

                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>















        </div>
    </div>

 <?php if (isset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655)): ?>
<?php $component = $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655; ?>
<?php unset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\sss-main\laravel_authontication\resources\views//faculty/event/view_event.blade.php ENDPATH**/ ?>
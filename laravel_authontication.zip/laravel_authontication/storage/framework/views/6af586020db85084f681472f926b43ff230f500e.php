 <?php if (isset($component)) { $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FacultyLayout::class, []); ?>
<?php $component->withName('faculty-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="container-fluid">

    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Add Event</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">Event</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">Add Event</a></li>
            </ol>
        </div>
    </div>
    <?php if(Session::has('event_created')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(Session::get('event_created')); ?>

    </div>
    <?php endif; ?>
    <div class="row">

















        
    </div>
</div>

 <?php if (isset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655)): ?>
<?php $component = $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655; ?>
<?php unset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\laravel_authontication\resources\views/faculty/event/add_event.blade.php ENDPATH**/ ?>
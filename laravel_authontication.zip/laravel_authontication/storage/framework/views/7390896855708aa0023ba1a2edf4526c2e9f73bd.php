 <?php if (isset($component)) { $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FacultyLayout::class, []); ?>
<?php $component->withName('faculty-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Student</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Student</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Edit Student</a></li>
                </ol>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-12">
                <div class="row tab-content">
                    <div id="list-view" class="tab-pane fade active show col-lg-12">
                        <div class="card">
                            <div class="card-header">

                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example5" class="display" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Name</th>
                                                <th>Enrl Number</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>Department</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="space">
                                                <td><img class="rounded-circle" style="height:35px; width:35px" src="<?php echo e(asset('upload/students/' . $data->photo)); ?>" alt="">
                                                </td>
                                                <td><?php echo e($data->f_name); ?></td>
                                                <td><a href="javascript:void(0);"><strong><?php echo e($data->e_number); ?></strong></a>
                                                </td>
                                                <td><a href="javascript:void(0);"><strong><?php echo e($data->m_number); ?></strong></a>
                                                </td>
                                                <td><a href="javascript:void(0);"><strong><?php echo e($data->email); ?></strong></a>
                                                </td>
                                                <td><?php echo e($data->department); ?></td>
                                                <td>
                                                    <a href="\faculty\edit_student\<?php echo e($data->id); ?>" class="btn btn-sm btn-primary"><i class="la la-pencil"></i></a>
                                                    <a data-action="<?php echo e(route('delete_student',$data->id)); ?>" class="remove-user btn btn-sm btn-danger" data-id="<?php echo e($data->id); ?>" title="Close"><i class="la la-trash-o"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
 <?php if (isset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655)): ?>
<?php $component = $__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655; ?>
<?php unset($__componentOriginal23c4bf4dec897e6c748115a854e8d9d1b9fda655); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\laravel_authontication\resources\views//faculty/student/edit_student_home.blade.php ENDPATH**/ ?>
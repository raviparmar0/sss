<x-admin-layout>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Event</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Event</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">All Event</a></li>
                </ol>
            </div>
        </div>
        @if(Session::has('event_added'))
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('event_added')}}
        </div>
        @endif
        <div class="row">


            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">View Event</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-1">
                            <table class="table m-1 table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr class="row">
                                        <th scope="col" class="col-md-3">Event Name</th>
                                        <th scope="col" class="col-md-2">Start Date</th>
                                        <th scope="col" class="col-md-2">End Date</th>
                                        <th scope="col" class="col-md-4">Discription</th>
                                        <th scope="col" class="col-md-1">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($alldata as $data)
                                    <tr class="row">
                                        <td scope="col" class="col-md-3">{{$data->e_name}}</td>
                                        <td scope="col" class="col-md-2">{{$data->s_date}} </td>
                                        <td scope="col" class="col-md-2">{{$data->e_date}}</td>
                                        <td scope="col" class="col-md-4">{{$data->dis}}</td>
                                        <td scope="col" class="col-md-1">
                                            <span>
                                                <a href="/download_event_admin/{{$data->file}}" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-download color-danger"></i></a>
                                            </span>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>















        </div>
    </div>

</x-admin-layout>
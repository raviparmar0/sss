<x-admin-layout>
    <div class="text-center">
        <h2>Admin Home</h2>
    </div>
</x-admin-layout>
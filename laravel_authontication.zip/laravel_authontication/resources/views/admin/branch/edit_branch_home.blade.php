<x-admin-layout>



    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Branch</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Branch</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Edit Branch</a></li>
                </ol>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit Branches</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Branch Name</th>
                                        <th scope="col">Total Seats</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($alldata as $data)
                                    <tr>
                                        <td>{{$data->b_name}}</td>
                                        <td>
                                            {{$data->seats}}
                                        </td>

                                        <td>
                                            <span>
                                                <a href="\admin\edit_branch\{{$data->id}}" class="mr-4" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil color-muted"></i> </a>
                                                <a data-action="{{ route('delete_branch',$data->id) }}" class="remove-user" data-id="{{ $data->id }}" title="Close"><i class="fa fa-close color-danger"></i></a>
                                                <!-- <a href="\admin\delete_branch\{{$data->id}}" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-close color-danger"></i></a> -->
                                            </span>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</x-admin-layout>
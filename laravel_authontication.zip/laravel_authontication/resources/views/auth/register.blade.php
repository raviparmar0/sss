<x-guest-layout>
    <x-jet-authentication-card>
        <x-slot name="logo">
        </x-slot>
        <div class="login-area">
            <div class="advisor-details-area">
                <div class="row advisor-info">
                    <div class="col-md-6 col-md-offset-3 content">
                        <div class="tab-info">
                            <ul class="nav-pills text-center">
                                <li class="col-md-12 active">
                                    <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                        Log in to your account
                                    </a>
                                </li>
                            </ul>
                            <br>
                            <br>
                            <div class="tab-content tab-content-info">
                                <!-- Single Tab -->
                                <div id="tab1" class="tab-pane fade active in">

                                    <form action="{{ route('register') }}" method="post" id="login-form">

                                        @csrf
                                        <x-jet-validation-errors class="mb-4" />

                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="form-group">
                                                    <input class="form-control" placeholder="Name" type="text"
                                                        name="name" required autofocusrequired autofocus
                                                        autocomplete="name">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="form-group">
                                                    <input class="form-control" placeholder="Email" type="email"
                                                        name="email" :value="old('email')" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="form-group">
                                                    <input class="form-control" placeholder="password" type="password"
                                                        name="password" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="form-group">
                                                    <input class="form-control" placeholder="password_confirmation"
                                                        type="password" name="password_confirmation" required>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="row">
                                                <button type="submit">
                                                    Register
                                                </button>
                                                <a class="underline text-sm hover:text-gray-900"
                                                    href="{{ route('login') }}">
                                                    {{ __('Already registered?') }}
                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!-- End Single Tab -->
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </x-jet-authentication-card>
</x-guest-layout>
<x-app-layout>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Company</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Placement</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">All company</a></li>
                </ol>
            </div>
        </div>
        @if(Session::has('staff_created'))
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('staff_created')}}
        </div>
        @endif
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">View Company</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Company Name</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Website</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($alldata as $data)
                                    <tr>
                                        <td>{{$data->c_name}}</td>
                                        <td>
                                            {{$data->type}}
                                        </td>
                                        <td>{{$data->website}}</td>
                                        <td>{{$data->phone}}
                                        </td>
                                        <td>
                                            {{$data->status}}
                                        </td>
                                        <td>
                                            <span>
                                                <a href="/download_company_student/{{$data->file}}" data-toggle="tooltip" data-placement="top" title="Download"><i class="fa fa-download color-danger"></i></a>

                                            </span>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

</x-app-layout>
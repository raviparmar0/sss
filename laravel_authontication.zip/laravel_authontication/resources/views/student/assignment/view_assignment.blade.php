<x-app-layout>

    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>All Assignment</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Assignment</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">All Assignment</a></li>
                </ol>
            </div>
        </div>
        @if(Session::has('assignment_created'))
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('assignment_created')}}
        </div>
        @endif
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">View Assignment</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-1">
                            <table class="table m-1 table-bordered verticle-middle table-responsive-sm">
                                <thead>
                                    <tr class="row">
                                        <th scope="col" class="col-md-2">Title</th>
                                        <th scope="col" class="col-md-2">Faculty</th>
                                        <th scope="col" class="col-md-1">Sem</th>
                                        <th scope="col" class="col-md-1">Points</th>
                                        <th scope="col" class="col-md-2">Due Date</th>
                                        <th scope="col" class="col-md-3">Discription</th>
                                        <th scope="col" class="col-md-1">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($alldata as $data)
                                    <tr class="row">
                                        <td scope="col" class="col-md-2">{{$data->a_name}}</td>
                                        <td scope="col" class="col-md-2">{{$data->f_name}}</td>
                                        <td scope="col" class="col-md-1">{{$data->semester}}</td>
                                        <td scope="col" class="col-md-1">{{$data->point}}</td>
                                        <td scope="col" class="col-md-2">{{$data->due_date}}</td>
                                        <td scope="col" class="col-md-3">{{$data->dis}}</td>
                                        <td scope="col" class="col-md-1">
                                            <span>
                                                <a href="/download_assignment_faculty/{{$data->file}}" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-download color-danger"></i></a>
                                            </span>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</x-app-layout>
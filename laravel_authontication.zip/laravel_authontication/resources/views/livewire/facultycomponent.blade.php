<div class="course-details-area">
    <br>
    <div class="container">
        <div class="row">
            <!-- Start Course Info -->
            <div class="col-md-12">
                <div class="courses-info">
                    <h2>
                        Facultys
                    </h2>
                    <div class="faq-inner">

                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">CIVIL ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($civi)
                                            @foreach($civi as $civi)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $civi->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$civi->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">COMPUTER ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($comp)
                                            @foreach($comp as $comp)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $comp->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$comp->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">ELECTRONICS & COMMUNICATION ENGG.<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($elec)
                                            @foreach($elec as $elec)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $elec->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$elec->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->

                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">INFORMATION TECHNOLOGY<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($info)
                                            @foreach($info as $info)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $info->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$info->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">MECHANICAL ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($mech)
                                            @foreach($mech as $mech)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $mech->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$mech->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                        <div class="faq-wrap">
                            <a href="#" class="question-toggle">PRODUCTION ENGINEERING<span><i class="fa fa-plus"></i></span></a>
                            <div class="faqanswer">
                                <!-- Start Advisor 
    ============================================= -->
                                <div class="advisor-area bg-gray bottom-less bg-cover">
                                    <div class="row">
                                        <div class="advisor-items col-3 text-light text-center">
                                            <!-- Single item -->
                                            @if($prod)
                                            @foreach($prod as $prod)
                                            <div class="col-md-3 col-sm-6 single-item">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="{{ asset('upload/faculties/' . $prod->photo) }}" alt="Thumb">
                                                    </div>
                                                    <div class="info">
                                                        <h4 style="color: #ffb606;">Mr.&nbsp{{$prod->f_name}}</h4>
                                                        <h5>ASSOCIATE&nbspPROFESSOR</h5>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                            @endif
                                            <!-- End Single item -->
                                        </div>
                                    </div>
                                </div>
                                <!-- End Advisor -->
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- End Course Info -->


        </div>
    </div>
</div>
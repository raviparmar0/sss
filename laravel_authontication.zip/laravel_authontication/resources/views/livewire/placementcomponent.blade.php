<div class="course-details-area">
    <br>
    <div class="container">
        <div class="row">
            <!-- Start Course Info -->
            <div class="col-md-12">
                <div class="courses-info">
                    <h2>
                        Placement Cell
                    </h2>

                    <!-- Star Tab Info -->
                    <div class="tab-info">
                        <!-- Tab Nav -->
                        <ul class="nav nav-pills">
                            <li class="active">
                                <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                    PLACEMENT CELL INFORMATION
                                </a>
                            </li>

                            <li>
                                <a data-toggle="tab" href="#tab3" aria-expanded="false">
                                    Selected Student
                                </a>
                            </li>

                        </ul>
                        <!-- End Tab Nav -->
                        <!-- Start Tab Content -->
                        <div class="tab-content tab-content-info">
                            <!-- Single Tab -->
                            <div id="tab1" class="tab-pane fade active in">
                                <div class="info title">
                                    <h4>About Training & Placement Cell</h4>
                                    <p> The purpose of the <B>Training and Placement Cell at GEC, Bhavnagar </B>, is to guide students to choose right career and to give knowledge, skill and aptitude and meet the manpower requirements of the Industry.</p>
                                    <p> The Training and Placement Cell of GEC Bhavnagar is facilitated by Training and Placement Officer as head and the Departmental Training and Placement Officers as coordinators. Student representatives from each department are assisting in overall coordination of the activities.</p>

                                    <h4>Tasks to be accomplished in every academic year</h4>
                                    <p> 1. To assist students to develop/clarify their academic and career interests, and their short and long-term goals through individual counselling and group sessions.
                                        <br>
                                        2. Maintaining and regularly updating database of students. Maintaining database of companies and establishing strategic links for campus recruitment.
                                        <br>
                                        3. Gathering information about job fairs and all relevant recruitment advertisements.
                                        <br>
                                        4. Coordinating with companies to learn about their requirements and recruitment procedures.
                                        <br>
                                        5. Identifying the needs and expectations of the companies to assist them in recruiting most suitable candidates.
                                        <br>
                                        6. Organizing pre-placement training/workshops/seminars for students.
                                        <br>
                                        7. Arranging periodic meetings with Human Resources Department of companies and TPO's to promote our institute.
                                        <br>
                                        8. Collecting feedback from employers where our students are selected.
                                        <br>
                                        9. To assist students for industrial training at the end of fourth and sixth semester.
                                        <br>
                                        10. To assist employers to achieve their hiring goals.
                                        .<br>
                                        11. To provide resources and activities to facilitate the career planning process.
                                        <br>
                                        12. To act as a link between students, alumni and the employment community.
                                        <br>
                                        13. To assist students in obtaining placement in reputed companies.
                                    </p>

                                    <h4>Career Guidance</h4>
                                    <p>
                                        1. Highlighting articles on departmental notice boards regarding Competitive & Industrial Career Opportunities.
                                        <br>
                                        2. Inform students about the available job opportunities in government sectors and off campus drives.
                                        <br>
                                        3. Giving Motivational Talks.
                                        <br>
                                        4. Conducting Psychometric Test.
                                        <br>
                                        5. Conducting Expectation Management Workshops.
                                    </p>

                                    <h4>Training & Development</h4>
                                    <p> Keeping in view the industry requirements, TP Cell helps students to be prepared to work as entry level Graduate Engineer Trainees. Following activates are planned for students to sharpen their skills and abilities.</p>
                                    <p>
                                        1. Personality Development
                                        <br>
                                        2. Communication Skills & Vocabulary
                                        <br>
                                        3. Resume Preparation& Email Writing
                                        <br>
                                        4. Group Discussion
                                        <br>
                                        5. Interview Skills
                                        <br>
                                        6. Aptitude Training & Practice Tests
                                    </p>

                                    <h4>Placement</h4>
                                    <p> The industry is always on the lookout for students who are vibrant, energetic individuals and ready to accept challenges, attentive, a good academic background, fast learners, open to learning even at work and more importantly, good communication skills.</p>
                                    <p> This activity focuses upon the personality development to make the students reliable, with positive attitude and right decision making.</p>
                                    <p>
                                        1. Guiding for preparation.
                                        <br>
                                        2. Arranging mock Interviews.
                                        <br>
                                        3. Communicating with Alumni for available openings.
                                        <br>
                                        4. Communicating with industry for campus interviews.
                                        <br>
                                        5. Arranging/Conducting campus recruitment drive as well as off campus drives.
                                    </p>

                                    <h4>Training & Placement Cell Team at GEC, Bhavnagar</h4>
                                    <table class="MsoNormalTable" border="1" cellpadding="0" width="952" xss="removed">
                                        <tbody>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" xss="removed" align="center"><b><span xss="removed">Sr. No.</span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed" align="center"><b><span xss="removed">Name</span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" xss="removed" align="center"><b><span xss="removed">Designation</span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed" align="center"><b><span xss="removed">E-MAIL ID</span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" xss="removed" align="center"><b><span xss="removed">Contact No.</span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                            </tr>
                                            <tr xss="removed">
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed">
                                                        <font size="4" color="#333300"><b xss="removed"><span xss="removed">1</span></b><span xss="removed">
                                                                <o></o>
                                                            </span></font>
                                                    </p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed">
                                                        <font size="4" color="#333300"><b><span xss="removed">Prof. (Dr.) A. K. Sarvaiya</span></b><span xss="removed">
                                                                <o></o>
                                                            </span></font>
                                                    </p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed">
                                                        <font size="4" color="#333300"><b><span xss="removed">TPO</span></b><span xss="removed">
                                                                <o></o>
                                                            </span></font>
                                                    </p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">
                                                            <font size="4" color="#333300"><b>tpo-gec-bhav@gujarat.gov.in</b>
                                                                <o></o>
                                                            </font>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><b><span xss="removed">
                                                                <font size="4" color="#333300">9898986857</font>
                                                            </span></b><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">2<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            (Dr.) N. N. Pandya (GENERAL)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Assistant TPO<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">nilesh_eternal@yahoo.com<o></o></span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9898312203<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">3<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            J. L. Ramdatti (PRODUCTION)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Assistant TPO<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">jlramdatti@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">8320322683<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">4<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            N. S. Patel (PRODUCTION)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Assistant TPO<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">mr.nikunjpatel1987@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9924426250<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">5<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            B. R Solanki (ELECTRICAL)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Assistant TPO<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">brijesh7004@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9725144933<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">6<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            S. H. Zala (MECHANICAL)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">zala.bpti@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9427755783<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">7<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            H. V. Mendpara (MECHANICAL)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">hardik.thermal@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9426067894<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">8<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            P. J. Gohel (EC)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">pratik.gohel09@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9067983626<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            Chintan Gajjar (CIVIL)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">cagcivilbvn@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9427558003<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">10<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            N. S. Chavda (IT)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">nishidh.bece@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9979073405<o></o></span></p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">11<o></o></span></p>
                                                </td>
                                                <td width="349" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">Prof.
                                                            K. P. Kandoriya (COMPUTER)<o></o></span></p>
                                                </td>
                                                <td width="160" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">Dept. Co-ordinator<o></o></span></p>
                                                </td>
                                                <td width="274" xss="removed">
                                                    <p class="MsoNormal" xss="removed"><span xss="removed">karshan.kandoriya@gmail.com</span><span xss="removed">
                                                            <o></o>
                                                        </span></p>
                                                </td>
                                                <td width="99" xss="removed">
                                                    <p class="MsoNormal" align="center" xss="removed"><span xss="removed">9033711408<o></o></span></p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <br>
                                </div>
                            </div>
                            <!-- End Single Tab -->



                            <!-- Single Tab -->
                            <div id="tab3" class="tab-pane fade">
                                <div class="info title">
                                    <div class="advisor-list-items row container">
                                        <!-- Advisor Item -->
                                        <div class="row">

                                            <div class="col-lg-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h4 class="card-title">Selected Students</h4>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered verticle-middle table-responsive-sm">
                                                                <thead>
                                                                    <tr>
                                                                        <th scope="col">Student Name</th>
                                                                        <th scope="col">Enrollment Number</th>
                                                                        <th scope="col">Company Name</th>
                                                                        <th scope="col">Branch</th>
                                                                        <th scope="col">Year</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    @foreach($alldata as $data)
                                                                    <tr>
                                                                        <td>{{$data->s_name}}</td>
                                                                        <td>
                                                                            {{$data->e_number}}
                                                                        </td>
                                                                        <td>{{$data->c_name}}</td>
                                                                        <td>{{$data->b_name}}
                                                                        </td>
                                                                        <td>
                                                                            {{$data->year}}
                                                                        </td>
                                                                    </tr>
                                                                    @endforeach
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        <!-- End Advisor Item -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Tab -->


                        </div>
                        <!-- End Tab Content -->
                    </div>
                    <!-- End Tab Info -->
                </div>
            </div>
            <!-- End Course Info -->


        </div>
    </div>
</div>
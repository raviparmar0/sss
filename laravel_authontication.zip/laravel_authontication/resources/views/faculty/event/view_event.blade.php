<x-faculty-layout>

<div class="container-fluid">

    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Event</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">Event</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">All Event</a></li>
            </ol>
        </div>
    </div>
    @if(Session::has('event_created'))
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        {{Session::get('event_created')}}
    </div>
    @endif
    <div class="row">

















        
    </div>
</div>

</x-faculty-layout>
<x-faculty-layout>
    Faculty
</x-faculty-layout>
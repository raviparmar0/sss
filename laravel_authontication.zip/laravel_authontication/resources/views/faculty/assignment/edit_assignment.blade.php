<x-faculty-layout>


    <div class="container-fluid">

        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Edit Assignment</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Assignment</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0);">Edit Assignment</a></li>
                </ol>
            </div>
        </div>
        @if(Session::has('assignment_created'))
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{Session::get('assignment_created')}}
        </div>
        @endif
        <div class="row">
            <div class="col-xl-12 col-xxl-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{route('update_assignment')}}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <input type="hidden" value="{{Auth::user()->name }}" name="f_name" class="form-control">
                                <input type="hidden" value="{{$assignments->id}}" name="id" class="form-control">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Department</label>
                                        <select class="form-control" name="d_name">
                                            @foreach($alldata as $data)
                                            <option value="{{$data->b_name}}" <?php if ($data->b_name == $assignments->d_name) echo ' selected="selected"'; ?>>{{$data->b_name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Semester</label>
                                        <select class="form-control" name="semester" required>
                                            <option value="1" <?php if (1 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 1</option>
                                            <option value="2" <?php if (2 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 2</option>
                                            <option value="3" <?php if (3 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 3</option>
                                            <option value="4" <?php if (4 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 4</option>
                                            <option value="5" <?php if (5 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 5</option>
                                            <option value="6" <?php if (6 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 6</option>
                                            <option value="7" <?php if (7 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 7</option>
                                            <option value="8" <?php if (8 == $assignments->semester) echo ' selected="selected"'; ?>>SEM 8</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Assignment Title</label>
                                        <input type="text" name="a_name" value="{{$assignments->a_name}}" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Points</label>
                                        <input type="text" name="point" value="{{$assignments->point}}" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Due Date</label>
                                        <input type="date" name="due_date" value="{{$assignments->due_date}}" class="datepicker form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Discription</label>
                                        <textarea class="form-control" name="dis" rows="5">{{$assignments->dis}}</textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                        <label class="form-label">Upload File</label>
                                        <input type="file" name="file" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</x-faculty-layout>
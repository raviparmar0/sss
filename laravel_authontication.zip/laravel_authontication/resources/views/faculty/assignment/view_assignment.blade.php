<x-faculty-layout>

<div class="container-fluid">

    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>All Assignment</h4>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">Assignment</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0);">All Assignment</a></li>
            </ol>
        </div>
    </div>
    @if(Session::has('assignment_created'))
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        {{Session::get('assignment_created')}}
    </div>
    @endif
    <div class="row">
       
    <div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">View Assignment</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered verticle-middle table-responsive-sm">
                    <thead>
                        <tr>
                            <th scope="col">Assignment Name</th>
                            <th scope="col">Faculty Name</th>
                            <th scope="col">Department</th>
                            <th scope="col">Semester</th>
                            <th scope="col">Due Date</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($alldata as $data)
                        <tr>
                            <td>{{$data->a_name}}</td>
                            <td>
                                {{$data->f_name}}
                            </td>
                            <td>{{$data->d_name}}</td>
                            <td>{{$data->semester}}</td>
                            <td>{{$data->due_date}}
                            </td>
                            <td>
                                <span>
                                    <a href="/download_assignment_faculty/{{$data->file}}" data-toggle="tooltip" data-placement="top" title="Close"><i class="fa fa-download color-danger"></i></a>
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

       
    </div>
</div>
</x-faculty-layout>
<?php return array (
  'contactcomponent' => 'App\\Http\\Livewire\\Contactcomponent',
  'cource.cecomponent' => 'App\\Http\\Livewire\\Cource\\Cecomponent',
  'cource.civilcomponent' => 'App\\Http\\Livewire\\Cource\\Civilcomponent',
  'cource.eccomponent' => 'App\\Http\\Livewire\\Cource\\Eccomponent',
  'cource.itcomponent' => 'App\\Http\\Livewire\\Cource\\Itcomponent',
  'cource.mecomponent' => 'App\\Http\\Livewire\\Cource\\Mecomponent',
  'cource.pecomponent' => 'App\\Http\\Livewire\\Cource\\Pecomponent',
  'facultycomponent' => 'App\\Http\\Livewire\\Facultycomponent',
  'feedbackcomponent' => 'App\\Http\\Livewire\\Feedbackcomponent',
  'generalcomponent' => 'App\\Http\\Livewire\\Generalcomponent',
  'homecomponent' => 'App\\Http\\Livewire\\Homecomponent',
  'principalcomponent' => 'App\\Http\\Livewire\\Principalcomponent',
);
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateApplyForCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apply_for_companies', function (Blueprint $table) {
            $table->id();
            $table->string('s_name');
            $table->string('email');
            $table->string('b_name');
            $table->string('c_name');
            $table->string('e_number');
            $table->string('cpi');
            $table->string('c_back');
            $table->string('p_10');
            $table->string('p_12');
            $table->string('dip');
            $table->string('d_cgpa');
            $table->string('year');
            $table->mediumText('resume');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('apply_for_companies');
    }
}

<?php

use App\Http\Livewire\Homecomponent;
use App\Http\Livewire\Principalcomponent;
use App\Http\Livewire\Facultycomponent;
use App\Http\Livewire\Generalcomponent;
use App\Http\Livewire\Feedbackcomponent;
use App\Http\Livewire\Contactcomponent;
use App\Http\Livewire\cource\Itcomponent;
use App\Http\Livewire\cource\Cecomponent;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\FacultyController;
use App\Http\Controllers\AssignmentController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\ApplyForCompanyController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\FullCalendarController;
use App\Http\Controllers\StudentController;
use App\Http\Livewire\cource\Mecomponent;
use App\Http\Livewire\cource\eccomponent;
use App\Http\Livewire\cource\civilcomponent;
use App\Http\Livewire\cource\pecomponent;







use App\Models\User;
use App\Models\Faculty;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', Homecomponent::class);

Route::get('/principal', Principalcomponent::class);

Route::get('/faculty', Facultycomponent::class);

Route::get('/general', Generalcomponent::class);

Route::get('/feedback', Feedbackcomponent::class);

Route::get('/contact', Contactcomponent::class);

Route::get('/branch/it', Itcomponent::class);

Route::get('/branch/ce', Cecomponent::class);

Route::get('/branch/me', Mecomponent::class);

Route::get('/branch/ec', eccomponent::class);

Route::get('/branch/civil', civilcomponent::class);

Route::get('/branch/pe', pecomponent::class);








/*********************     Student start        ********************************/
Route::middleware(['auth:sanctum', 'verified'])->get('/student/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

//assignment

Route::middleware(['auth:sanctum', 'verified'])->get('/student/view_assignment', [AssignmentController::class, 'view_assignment_student'])->name('view_assignment_student');

Route::middleware(['auth:sanctum', 'verified'])->get('/download_assignment_student/{file}', [AssignmentController::class, 'download_assignment_student'])->name('download_assignment_student');

//company


Route::middleware(['auth:sanctum', 'verified'])->get('/student/view_company', [CompanyController::class, 'view_company_student'])->name('view_company_student');

Route::middleware(['auth:sanctum', 'verified'])->get('/download_company_student/{file}', [CompanyController::class, 'download_company_student'])->name('download_company_student');

Route::middleware(['auth:sanctum', 'verified'])->get('/student/apply_company', [CompanyController::class, 'apply_company'])->name('apply_company');

//apply company

Route::middleware(['auth:sanctum', 'verified'])->get('/admin/apply_company', function () {
    return view('student.company.apply_company');
})->name('student.apply_company');


Route::middleware(['auth:sanctum', 'verified'])->post('/apply_company_submit', [ApplyForCompanyController::class, 'apply_company_submit'])->name('apply_company_submit');

Route::middleware(['auth:sanctum', 'verified'])->get('/student/companies_applied', [ApplyForCompanyController::class, 'companies_applied_student'])->name('companies_applied_student');












/*********************     Student end        ********************************/





/*********************     Admin start        ********************************/

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/dashboard', function () {
    return view('admin.dashboard');
})->name('admin.dashboard');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/add_faculty', function () {
    return view('admin.faculty.add_faculty');
})->name('admin.add_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->post('/add_fuculty_submit', [FacultyController::class, 'add_fuculty_submit'])->name('add_fuculty_submit');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/view_faculty', [FacultyController::class, 'view_faculty'])->name('view_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/edit_faculty_home', [FacultyController::class, 'edit_faculty_home'])->name('edit_faculty_home');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/edit_faculty/{id}', [FacultyController::class, 'edit_faculty'])->name('edit_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->post('/admin/update_faculty', [FacultyController::class, 'update_faculty'])->name('update_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->delete('/admin/delete_faculty/{id}', [FacultyController::class, 'delete_faculty'])->name('delete_faculty');




// branch
Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/add_branch', function () {
    return view('admin.branch.add_branch');
})->name('admin.add_branch');


Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->post('/add_branch_submit', [BranchController::class, 'add_branch_submit'])->name('add_branch_submit');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/view_branch', [BranchController::class, 'view_branch'])->name('view_branch');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/edit_branch_home', [BranchController::class, 'edit_branch_home'])->name('edit_branch_home');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->get('/admin/edit_branch/{id}', [BranchController::class, 'edit_branch'])->name('edit_branch');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->post('/admin/update_branch', [BranchController::class, 'update_branch'])->name('update_branch');

Route::middleware(['auth:sanctum', 'verified', 'authadmin'])->delete('/admin/delete_branch/{id}', [BranchController::class, 'delete_branch'])->name('delete_branch');


/*********************     Admin end        ********************************/




/*********************     Faculty start        ********************************/

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/dashboard', function () {
    return view('faculty.dashboard');
})->name('faculty.dashboard');


//student
Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/add_student', function () {
    return view('faculty.student.add_student');
})->name('faculty.add_student');


Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/add_student_submit', [StudentController::class, 'add_student_submit'])->name('add_student_submit');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/view_student', [StudentController::class, 'view_student'])->name('view_student');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_student_home', [StudentController::class, 'edit_student_home'])->name('edit_student_home');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_student/{id}', [StudentController::class, 'edit_student'])->name('edit_student');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/faculty/update_student', [StudentController::class, 'update_student'])->name('update_student');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->delete('/faculty/delete_student/{id}', [StudentController::class, 'delete_student'])->name('delete_student');




//assigmnent

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/add_assignment', function () {
    return view('faculty.assignment.add_assignment');
})->name('faculty.add_assignment');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/add_assignment_submit', [AssignmentController::class, 'add_assignment_submit'])->name('add_assignment_submit');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/view_assignment', [AssignmentController::class, 'view_assignment_faculty'])->name('view_assignment');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_assignment_home', [AssignmentController::class, 'edit_assignment_home'])->name('edit_assignment_home');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_assignment/{id}', [AssignmentController::class, 'edit_assignment'])->name('edit_assignment');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/faculty/update_assignment', [AssignmentController::class, 'update_assignment'])->name('update_assignment');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->delete('/faculty/delete_assignment/{id}', [AssignmentController::class, 'delete_assignment'])->name('delete_assignment');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/download_assignment_faculty/{file}', [AssignmentController::class, 'download_assignment_faculty'])->name('download_assignment_faculty');


//company

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/add_company', function () {
    return view('faculty.company.add_company');
})->name('faculty.add_company');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/add_company_submit', [CompanyController::class, 'add_company_submit'])->name('add_company_submit');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/view_company_faculty', [CompanyController::class, 'view_company_faculty'])->name('view_company_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_company/{id}', [CompanyController::class, 'edit_company'])->name('edit_company');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/faculty/update_company', [CompanyController::class, 'update_company'])->name('update_company');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->delete('/faculty/delete_company/{id}', [CompanyController::class, 'delete_company'])->name('delete_company');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/download_company_faculty/{file}', [CompanyController::class, 'download_company_faculty'])->name('download_company_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/companies_applied', [ApplyForCompanyController::class, 'companies_applied_faculty'])->name('companies_applied_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/download_resumes_faculty/{file}', [ApplyForCompanyController::class, 'download_resumes_faculty'])->name('download_resumes_faculty');






//event

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/add_event', function () {
    return view('faculty.event.add_event');
})->name('faculty.add_event');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/add_event_submit', [EventController::class, 'add_event_submit'])->name('add_event_submit');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/view_event_faculty', [EventController::class, 'view_event_faculty'])->name('view_event_faculty');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/faculty/edit_event/{id}', [EventController::class, 'edit_event'])->name('edit_event');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->post('/faculty/update_event', [EventController::class, 'update_event'])->name('update_event');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->delete('/faculty/delete_event/{id}', [EventController::class, 'delete_event'])->name('delete_event');

Route::middleware(['auth:sanctum', 'verified', 'authfaculty'])->get('/download_event_faculty/{file}', [EventController::class, 'download_event_faculty'])->name('download_event_faculty');









/*********************     Faculty end        ********************************/

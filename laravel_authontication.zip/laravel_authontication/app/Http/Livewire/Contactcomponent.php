<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Contactcomponent extends Component
{
    public function render()
    {
        return view('livewire.contactcomponent')->layout('layouts.index');
    }
}
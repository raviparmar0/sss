<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\DB;


class Placementcomponent extends Component
{
    public function render()
    {
        $alldata = DB::select('SELECT * FROM `selected_students` ORDER BY id DESC');
        return view('livewire.placementcomponent')->with('alldata', $alldata)->layout('layouts.index');
    }
}

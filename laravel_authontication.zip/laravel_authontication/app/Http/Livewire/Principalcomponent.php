<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Principalcomponent extends Component
{
    public function render()
    {
        return view('livewire.principalcomponent')->layout('layouts.index');
    }
}
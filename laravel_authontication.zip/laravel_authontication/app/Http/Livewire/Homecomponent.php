<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\View\Components\AppLayout;
use App\View\Components\GuestLayout;
use Illuminate\View\Compilers\Concerns\CompilesLayouts;

class Homecomponent extends Component
{
    public function render()
    {
        return view('livewire.homecomponent')->layout('layouts.index');
    }
}
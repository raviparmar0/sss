<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\View\Components\AppLayout;
use App\View\Components\GuestLayout;
use Illuminate\View\Compilers\Concerns\CompilesLayouts;
use Illuminate\Support\Facades\DB;

class Homecomponent extends Component
{
    public function render()
    {
        $admin = DB::select("SELECT * FROM `users` WHERE `utype` = 'ADM'");
        return view('livewire.homecomponent')->with('admin', $admin)->layout('layouts.index');
    }
}

<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Pecomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.pecomponent')->layout('layouts.index');
    }
}

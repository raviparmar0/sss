<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;
use App\Models\Faculty;

class Mecomponent extends Component
{
    public function render()
    {
        $alldata = Faculty::all()->where('department', 'MECHANICAL ENGINEERING');
        return view('livewire.cource.mecomponent')->with('alldata', $alldata)->layout('layouts.index');
    }
}

<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Mecomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.mecomponent')->layout('layouts.index');
    }
}

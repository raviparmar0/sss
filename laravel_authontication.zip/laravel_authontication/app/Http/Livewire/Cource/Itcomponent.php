<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Itcomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.itcomponent')->layout('layouts.index');
    }
}

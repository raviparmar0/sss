<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Civilcomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.civilcomponent')->layout('layouts.index');
    }
}

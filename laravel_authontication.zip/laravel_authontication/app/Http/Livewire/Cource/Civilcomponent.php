<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;
use App\Models\Faculty;

class Civilcomponent extends Component
{
    public function render()
    {
        $alldata = Faculty::all()->where('department', 'CIVIL ENGINEERING');
        return view('livewire.cource.civilcomponent')->with('alldata', $alldata)->layout('layouts.index');
    }
}

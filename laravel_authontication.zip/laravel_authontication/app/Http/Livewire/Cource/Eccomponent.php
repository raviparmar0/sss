<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Eccomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.eccomponent')->layout('layouts.index');
    }
}

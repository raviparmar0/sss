<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;
use App\Models\Faculty;

class Eccomponent extends Component
{
    public function render()
    {
        $alldata = Faculty::all()->where('department', 'ELECTRONINCS & COMMUNICATION');
        return view('livewire.cource.eccomponent')->with('alldata', $alldata)->layout('layouts.index');
    }
}

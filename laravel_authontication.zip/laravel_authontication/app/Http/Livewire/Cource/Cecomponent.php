<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;

class Cecomponent extends Component
{
    public function render()
    {
        return view('livewire.cource.cecomponent')->layout('layouts.index');
    }
}

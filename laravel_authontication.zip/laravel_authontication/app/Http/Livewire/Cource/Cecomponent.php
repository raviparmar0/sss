<?php

namespace App\Http\Livewire\Cource;

use Livewire\Component;
use App\Models\Faculty;

class Cecomponent extends Component
{
    public function render()
    {
        $alldata = Faculty::all()->where('department', 'COMPUTER ENGINEERING');
        return view('livewire.cource.cecomponent')->with('alldata', $alldata)->layout('layouts.index');
    }
}

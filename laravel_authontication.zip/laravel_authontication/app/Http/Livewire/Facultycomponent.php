<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Facultycomponent extends Component
{
    public function render()
    {
        return view('livewire.facultycomponent')->layout('layouts.index');
    }
}
<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Faculty;

class Facultycomponent extends Component
{
    public function render()
    {
        $comp = Faculty::all()->where('department', 'COMPUTER ENGINEERING');
        $civi = Faculty::all()->where('department', 'CIVIL ENGINEERING');
        $elec = Faculty::all()->where('department', 'ELECTRONINCS & COMMUNICATION');
        $info = Faculty::all()->where('department', 'INFORMATION TECHNOLOGY');
        $mech = Faculty::all()->where('department', 'MECHANICAL ENGINEERING');
        $prod = Faculty::all()->where('department', 'PRODUCTION ENGINEERING');
        return view('livewire.facultycomponent')->with(['comp' => $comp, 'civi' => $civi, 'elec' => $elec, 'info' => $info, 'mech' => $mech, 'prod' => $prod])->layout('layouts.index');
    }
}

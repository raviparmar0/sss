<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use App\Models\Apply_for_company;
use App\Models\Selected_student;
use App\Models\Student;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Http\Request;

class ApplyForCompanyController extends Controller
{
    public function apply_company_submit(Request $request)
    {

        $student = DB::table('students')->where('email', $request->input('email'))->first();

        $apply_for_companies  = new Apply_for_company();
        $apply_for_companies->s_name = $student->f_name . ' ' . $student->l_name;
        $apply_for_companies->email = $student->email;
        $apply_for_companies->b_name = $student->department;
        $apply_for_companies->e_number = $student->e_number;
        $apply_for_companies->c_name = $request->input('c_name');
        $apply_for_companies->cpi = $request->input('cpi');
        $apply_for_companies->c_back = $request->input('c_back');
        $apply_for_companies->p_10 = $request->input('p_10');
        $apply_for_companies->p_12 = $request->input('p_12');
        $apply_for_companies->dip = $request->input('dip');
        $apply_for_companies->d_cgpa = $request->input('d_cgpa');



        if ($request->hasFile('resume')) {
            $file = $request->file('resume');
            $extension = $file->getClientOriginalExtension();
            $filename = $student->e_number . '.' . $extension;
            $file->move('upload/resumes/', $filename);
            $apply_for_companies->resume = $filename;
        } else {
            return $request;
            $apply_for_companies->resume = '';
        }

        $apply_for_companies->save();

        return redirect('/student/apply_company')->with('apply_company', 'Company Has Been Applied.....!');
    }

    public function selected_student_submit(Request $request)
    {
        $apply_for_companies  = new Selected_student();
        $apply_for_companies->s_name = $request->input('s_name');
        $apply_for_companies->b_name = $request->input('b_name');
        $apply_for_companies->e_number = $request->input('e_number');
        $apply_for_companies->c_name = $request->input('c_name');
        $apply_for_companies->year = $request->input('year');
        $apply_for_companies->save();

        return redirect('/faculty/selected_student')->with('student_added', 'Selected student Has Been Added.....!');
    }




    public function companies_applied($email)
    {
        $student = DB::table('students')->where('email', $email)->first();
        $alldata = Apply_for_company::all()->where('e_number', $student->e_number);
        return view('/student/company/companies_applied')->with('alldata', $alldata);
    }

    public function companies_applied_student()
    {
        $alldata = Apply_for_company::all();
        return view('/student/company/companies_applied')->with('alldata', $alldata);
    }

    public function companies_applied_faculty()
    {
        $alldata = Apply_for_company::all();
        return view('/faculty/company/companies_applied')->with('alldata', $alldata);
    }

    public function download_resumes_faculty($resume)
    {
        return response()->download('upload/resumes/' . $resume);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Faculty;
use Illuminate\Support\Facades\DB;
use App\Models\User;




class FacultyController extends Controller
{
    public function add_fuculty_submit(Request $request)
    {
        $alldata1 = User::all();
        foreach ($alldata1 as $data) {
            if ($data->email == $request->input('email')) {
                return redirect('/admin/add_faculty')->with('faculties_created', 'Email Already Exist..');
            }
        }


        $faculties = new Faculty();
        $faculties->f_name = $request->input('f_name');
        $faculties->l_name = $request->input('l_name');
        $faculties->email = $request->input('email');
        $faculties->join_date = $request->input('join_date');
        $faculties->password = $request->input('password');
        $faculties->password_confirmation = $request->input('password_confirmation');
        $faculties->m_number = $request->input('m_number');
        $faculties->gender = $request->input('gender');
        $faculties->designation = $request->input('designation');
        $faculties->department = $request->input('department');
        $faculties->dob = $request->input('dob');
        $faculties->qualification = $request->input('qualification');
        $faculties->experience = $request->input('experience');
        $faculties->interest = $request->input('interest');
        $faculties->address = $request->input('address');



        if ($request->hasFile('photo')) {
            $file = $request->file('photo');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/faculties/', $filename);
            $faculties->photo = $filename;
        } else {
            return $request;
            $faculties->photo = '';
        }

        $faculties->save();

        $user = new User();
        $user->email = $request->input('email');
        $user->name = $request->input('f_name');
        $user->password = Hash::make($request->input('password'));
        $user->utype = 'FAC';

        $user->save();

        return redirect('/admin/add_faculty')->with('faculties_created', 'faculty has been created.....!');
    }

    public function view_faculty()
    {

        $alldata = Faculty::all();
        return view('/admin/faculty/view_faculty')->with('alldata', $alldata);
    }

    public function edit_faculty_home()
    {
        $alldata = Faculty::all();
        return view('/admin/faculty/edit_faculty_home')->with('alldata', $alldata);
    }

    public function edit_faculty($id)
    {
        $staff = DB::table('faculties')->where('id', $id)->first();
        return view('/admin/faculty/edit_faculty', compact('staff'));
    }

    public function update_faculty(Request $request)
    {
        $id = $request->get('id');
        $update = [
            'f_name' => $request->f_name,
            'l_name' => $request->l_name,
            'email' => $request->email,
            'join_date' => $request->join_date,
            'password' => $request->password,
            'password_confirmation' => $request->password_confirmation,
            'm_number' => $request->m_number,
            'gender' => $request->gender,
            'designation' => $request->designation,
            'department' => $request->department,
            'dob' => $request->dob,
            'qualification' => $request->qualification,
            'experience' => $request->experience,
            'interest' => $request->interest,
            'address' => $request->address,
        ];
        if ($files = $request->file('photo')) {
            $destinationPath = 'upload/faculties/'; // upload path
            $profileImage = time() . "." . $files->getClientOriginalExtension();
            $files->move($destinationPath, $profileImage);
            $update['photo'] = "$profileImage";
        }
        Faculty::where('id', $id)->update($update);
        return redirect('/admin/edit_faculty_home');
    }

    public function delete_faculty($id)
    {
        Faculty::where('id', $id)->delete();
        return Redirect('/admin/edit_faculty_home');
    }
}

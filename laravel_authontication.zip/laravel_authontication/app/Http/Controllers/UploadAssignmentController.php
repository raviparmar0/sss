<?php

namespace App\Http\Controllers;

use App\Models\Upload_assignment;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Http\Request;

class UploadAssignmentController extends Controller
{
    public function upload_assignment_submit(Request $request)
    {
        $upload_assignments  = new Upload_assignment();
        $upload_assignments->a_name = $request->input('a_name');
        $upload_assignments->s_name = $request->input('s_name');
        $upload_assignments->c_date = $request->input('c_date');

        if ($request->hasFile('s_file')) {
            $file = $request->file('s_file');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/submitted_assignments/', $filename);
            $upload_assignments->s_file = $filename;
        } else {
            return $request;
            $upload_assignments->s_file = '';
        }

        $upload_assignments->save();

        return redirect('/student/assignment/submit_assignment')->with('assignment_uploaded', 'Assignment Has Been Uploaded.....!');
    }

    public function submit_assignment_student(Request $request)
    {
        return view('/student/submit_assignment');
    }


    public function submit_assignment_faculty()
    {
        $alldata = upload_assignment::all();
        return view('/faculty/assignment/submit_assignment')->with('alldata', $alldata);
    }

    public function download_uploaded_assignment($file)
    {
        return response()->download('upload/submitted_assignments/' . $file);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Student;
use App\Models\Branch;
use Illuminate\Support\Facades\DB;
use App\Models\User;


class StudentController extends Controller
{
    public function add_student_submit(Request $request)
    {
        if ($request->input('password') != $request->input('password_confirmation')) {
            return redirect('/faculty/add_student')->with('student_created', 'Password And Confirm Password not match');
        }

        $alldata1 = User::all();
        foreach ($alldata1 as $data) {
            if ($data->email == $request->input('email')) {
                return redirect('/faculty/add_student')->with('student_created', 'Email Already Exist..');
            }
        }
        $alldata1 = Student::all();
        foreach ($alldata1 as $data) {
            if ($data->e_number == $request->input('e_number')) {
                return redirect('/faculty/add_student')->with('student_created', 'Enrollment Already Exist..');
            }
        }
        $students = new Student();
        $students->f_name = $request->input('f_name');
        $students->l_name = $request->input('l_name');
        $students->email = $request->input('email');
        $students->e_number = $request->input('e_number');
        $students->m_number = $request->input('m_number');
        $students->dob = $request->input('dob');
        $students->gender = $request->input('gender');
        $students->department = $request->input('department');
        $students->password = $request->input('password');
        $students->password_confirmation = $request->input('password_confirmation');
        $students->address = $request->input('address');


        if ($request->hasFile('photo')) {
            $file = $request->file('photo');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/students/', $filename);
            $students->photo = $filename;
        } else {
            return $request;
            $students->photo = '';
        }

        $students->save();

        $user = new User();
        $user->email = $request->input('email');
        $user->name = $request->input('f_name');
        $user->password = Hash::make($request->input('password'));
        $user->utype = 'STU';

        $user->save();

        return redirect('/faculty/add_student')->with('student_created', 'student has been created.....!');
    }

    public function view_student()
    {

        $alldata = Student::all();
        return view('/faculty/student/view_student')->with('alldata', $alldata);
    }

    public function edit_student_home()
    {
        $alldata = Student::all();
        return view('/faculty/student/edit_student_home')->with('alldata', $alldata);
    }

    public function edit_student($id)
    {
        $student = DB::table('students')->where('id', $id)->first();
        $alldata = Branch::all();
        return view('/faculty/student/edit_student', compact('student', 'alldata'));
    }

    public function update_student(Request $request)
    {
        $id = $request->get('id');
        $student = DB::table('students')->where('id', $id)->first();
        $update = [
            'f_name' => $request->f_name,
            'l_name' => $request->l_name,
            'email' => $request->email,
            'e_number' => $request->e_number,
            'password' => $request->password,
            'password_confirmation' => $request->password_confirmation,
            'm_number' => $request->m_number,
            'gender' => $request->gender,
            'department' => $request->department,
            'dob' => $request->dob,
            'address' => $request->address,
        ];
        if ($files = $request->file('photo')) {
            $destinationPath = 'upload/students/'; // upload path
            $profileImage = time() . "." . $files->getClientOriginalExtension();
            $files->move($destinationPath, $profileImage);
            $update['photo'] = "$profileImage";
        }
        Student::where('id', $id)->update($update);

        $user = [
            'name' => $request->f_name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ];
        User::where('email', $student->email)->update($user);

        return redirect('/faculty/edit_student_home');
    }

    public function delete_student($id)
    {
        $student = DB::table('students')->where('id', $id)->first();
        Student::where('id', $id)->delete();
        User::where('email', $student->email)->delete();
        return Redirect('/faculty/edit_student_home');
    }
}

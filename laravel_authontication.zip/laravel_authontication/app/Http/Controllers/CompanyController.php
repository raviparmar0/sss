<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use App\Models\Company;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Branch;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public function add_company_submit(Request $request)
    {

        $companies  = new Company();
        $companies->c_name = $request->input('c_name');
        $companies->website = $request->input('website');
        $companies->type = $request->input('type');
        $companies->status = $request->input('status');
        $companies->phone = $request->input('phone');
        $companies->b_name = $request->input('b_name');
        $companies->address = $request->input('address');
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/company/', $filename);
            $companies->file = $filename;
        } else {
            return $request;
            $companies->file = '';
        }
        $companies->save();
        return redirect('/faculty/add_company')->with('company_created', 'company has been created.....!');
    }

    public function view_company_faculty()
    {
        $alldata = company::all();
        return view('/faculty/company/view_company')->with('alldata', $alldata);
    }

    public function view_company_student()
    {
        $alldata = company::all();
        return view('/student/company/view_company')->with('alldata', $alldata);
    }

    public function view_company_admin()
    {
        $alldata = company::all();
        return view('/admin/company/view_company')->with('alldata', $alldata);
    }

    public function edit_company($id)
    {
        $alldata = Branch::all();
        $companies = DB::table('companies')->where('id', $id)->first();
        return view('faculty/company/edit_company', compact('companies', 'alldata'));
    }

    public function update_company(Request $request)
    {
        $id = $request->get('id');
        $update = [
            'c_name' => $request->c_name,
            'website' => $request->website,
            'type' => $request->type,
            'status' => $request->status,
            'phone' => $request->phone,
            'b_name' => $request->b_name,
            'address' => $request->address,


        ];
        if ($files = $request->file('file')) {
            $destinationPath = 'upload/company/'; // upload path
            $profileImage = time() . "." . $files->getClientOriginalExtension();
            $files->move($destinationPath, $profileImage);
            $update['file'] = "$profileImage";
        }
        Company::where('id', $id)->update($update);
        return redirect('/faculty/view_company_faculty');
    }


    public function delete_company($id)
    {
        company::where('id', $id)->delete();
        return Redirect('/faculty/view_company_faculty')->with('success', 'Company deleted successfully');
    }

    public function download_company_faculty($file)
    {
        return response()->download('upload/company/' . $file);
    }

    public function download_company_student($file)
    {
        return response()->download('upload/company/' . $file);
    }

    public function apply_company()
    {
        $alldata = company::all();
        return view('/student/company/apply_company')->with('alldata', $alldata);
    }
    public function selected_student()
    {
        $alldata = company::all();
        return view('/faculty/company/selected_student')->with('alldata', $alldata);
    }
}

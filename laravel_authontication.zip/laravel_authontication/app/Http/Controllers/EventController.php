<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use App\Models\Event;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Branch;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function add_event_submit(Request $request)
    {

        $events  = new Event();
        $events->e_name = $request->input('e_name');
        $events->s_date = $request->input('s_date');
        $events->e_date = $request->input('e_date');
        $events->dis = $request->input('dis');
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/event/', $filename);
            $events->file = $filename;
        } else {
            return $request;
            $events->file = '';
        }
        $events->save();
        return redirect('/faculty/add_event')->with('event_added', 'event has been added.....!');
    }

    public function view_event_faculty()
    {
        $alldata = event::all();
        return view('/faculty/event/view_event')->with('alldata', $alldata);
    }

    public function view_event_student()
    {
        $alldata = event::all();
        return view('/student/event/view_event')->with('alldata', $alldata);
    }

    public function view_event_admin()
    {
        $alldata = event::all();
        return view('/admin/event/view_event')->with('alldata', $alldata);
    }

    public function edit_event($id)
    {
        $alldata = Branch::all();
        $events = DB::table('events')->where('id', $id)->first();
        return view('faculty/event/edit_event', compact('events', 'alldata'));
    }

    public function update_event(Request $request)
    {
        $id = $request->get('id');
        $update = [
            'e_name' => $request->e_name,
            's_date' => $request->s_date,
            'e_date' => $request->e_date,
            'dis' => $request->dis,
        ];
        if ($files = $request->file('file')) {
            $destinationPath = 'upload/event/'; // upload path
            $profileImage = time() . "." . $files->getClientOriginalExtension();
            $files->move($destinationPath, $profileImage);
            $update['file'] = "$profileImage";
        }
        Event::where('id', $id)->update($update);
        return redirect('/faculty/view_event_faculty');
    }


    public function delete_event($id)
    {
        event::where('id', $id)->delete();
        return Redirect('/faculty/view_event_faculty')->with('success', 'Event deleted successfully');
    }

    public function download_event_faculty($file)
    {
        return response()->download('upload/event/' . $file);
    }

    public function download_event_student($file)
    {
        return response()->download('upload/event/' . $file);
    }

    public function download_event_admin($file)
    {
        return response()->download('upload/event/' . $file);
    }
}

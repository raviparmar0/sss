<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use App\Models\Assignment;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Http\Request;

class AssignmentController extends Controller
{
    public function view_assignment_faculty()
    {
        $alldata = assignment::all();
        return view('/faculty/assignment/view_assignment')->with('alldata', $alldata);
    }

    public function view_assignment_student()
    {
        $alldata = assignment::all();
        return view('/student/assignment/view_assignment')->with('alldata', $alldata);
    }

    public function add_assignment()
    {
        return view('/faculty/assignment/add_assignment');
    }

    public function add_assignment_submit(Request $request)
    {
        $assignments  = new Assignment();
        $assignments->f_name = $request->input('f_name');
        $assignments->semester = $request->input('semester');
        $assignments->a_name = $request->input('a_name');
        $assignments->due_date = $request->input('due_date');
        $assignments->d_name = $request->input('d_name');
        $assignments->point = $request->input('point');
        $assignments->dis = $request->input('dis');



        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('upload/assignment/', $filename);
            $assignments->file = $filename;
        } else {
            return $request;
            $assignments->file = '';
        }

        $assignments->save();

        return redirect('/faculty/add_assignment')->with('assignment_created', 'Assignment Has Been Uploaded.....!');
    }
    public function download_assignment_faculty($file)
    {
        return response()->download('upload/assignment/' . $file);
    }

    public function download_assignment_student($file)
    {
        return response()->download('upload/assignment/' . $file);
    }

    public function edit_assignment_home()
    {
        $alldata = Assignment::all();
        return view('faculty/assignment/edit_assignment_home')->with('alldata', $alldata);
    }

    public function edit_assignment($id)
    {
        $assignments = DB::table('assignments')->where('id', $id)->first();
        return view('faculty/assignment/edit_assignment', compact('assignments'));
    }

    public function update_assignment(Request $request)
    {
        $id = $request->get('id');
        $update = [
            'f_name' => $request->f_name,
            'semester' => $request->semester,
            'a_name' => $request->a_name,
            'd_name' => $request->d_name,
            'due_date' => $request->due_date,
            'point' => $request->point,
            'dis' => $request->dis,

        ];
        if ($files = $request->file('file')) {
            $destinationPath = 'upload/assignment/'; // upload path
            $profileImage = time() . "." . $files->getClientOriginalExtension();
            $files->move($destinationPath, $profileImage);
            $update['file'] = "$profileImage";
        }
        Assignment::where('id', $id)->update($update);
        return redirect('/faculty/edit_assignment_home');
    }

    public function delete_assignment($id)
    {
        assignment::where('id', $id)->delete();
        return Redirect('/faculty/edit_assignment_home')->with('success', 'Product deleted successfully');
    }
}

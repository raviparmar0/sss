<?php

namespace App\Http\Controllers;

use App\Models\Faculty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Cource extends Controller
{
    public function it()
    {
        $alldata = Faculty::all()->where('department', 'INFORMATION TECHNOLOGY');
        return view('cources/it')->with('alldata', $alldata);
        $it = DB::table('faculties')->where('department', 'INFORMATION TECHNOLOGY')->first();
        return view('livewire.cource.itcomponent')->with('it', $it)->layout('layouts.index');
    }
}

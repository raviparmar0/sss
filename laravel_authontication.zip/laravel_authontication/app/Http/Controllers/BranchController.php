<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Branch;
use Illuminate\Support\Facades\DB;
use App\Models\User;



class BranchController extends Controller
{
    public function add_branch()
    {
        return view('admin/branch/add_branch');
    }

    public function add_branch_submit(Request $request)
    {
        $branch  = new branch();
        $branch->b_name = $request->input('b_name');
        $branch->seats = $request->input('seats');
        $branch->save();
        return redirect('admin/add_branch')->with('branch_created', 'branch has been created.....!');
    }

    public function view_branch()
    {
        $alldata = branch::all();
        return view('admin/branch/view_branch')->with('alldata', $alldata);
    }

    public function edit_branch_home()
    {

        $alldata = branch::all();
        return view('admin/branch/edit_branch_home')->with('alldata', $alldata);
    }

    public function edit_branch($id)
    {
        $branch = DB::table('branches')->where('id', $id)->first();
        return view('admin/branch/edit_branch', compact('branch'));
    }

    public function update_branch(Request $request)
    {
        $id = $request->get('id');
        $update = [
            'b_name' => $request->b_name,
            'seats' => $request->seats,
        ];

        branch::where('id', $id)->update($update);
        return redirect('/admin/edit_branch_home');
    }

    public function delete_branch($id)
    {
        branch::where('id', $id)->delete();
        return Redirect('/admin/edit_branch_home')->with('success', 'Product deleted successfully');
    }
}

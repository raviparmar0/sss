<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Faculty extends Model
{
    use HasFactory;
    protected $table = 'faculties';
    protected $fillable = ['f_name', 'l_name', 'email', 'join_date', 'password', 'password_confirmation', 'm_number', 'gender', 'designation', 'department', 'dob', 'qualification', 'qualification', 'interest', 'address', 'photo'];
}
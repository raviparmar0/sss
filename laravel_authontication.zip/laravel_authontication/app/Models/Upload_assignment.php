<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Upload_assignment extends Model
{
    use HasFactory;

    protected $table = 'upload_assignments';
    protected $fillable = ['a_name', 'c_date', 's_file', 's_name'];
}

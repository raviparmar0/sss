<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Selected_student extends Model
{
    use HasFactory;
    protected $table = 'selected_students';
    protected $fillable = ['s_name', 'b_name', 'e_number', 'c_name', 'year'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;
    protected $table = 'students';
    protected $fillable = ['f_name', 'l_name', 'email', 'password', 'password_confirmation', 'm_number', 'gender',  'department', 'dob',   'address', 'photo'];
}

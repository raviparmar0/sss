<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Apply_for_company extends Model
{
    use HasFactory;
    protected $table = 'apply_for_companies';
    protected $fillable = ['s_name', 'email', 'b_name', 'c_name','cpi','c_back','p_10','p_12','dip','d_cgpa','resume'];
}
